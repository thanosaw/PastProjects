//
//  Game.hpp
//  Project1cs32
//
//  Created by Andrew Wang on 1/4/22.
//

#ifndef Game_h
#define Game_h



///////////////////////////////////////////////////////////////////////////
// Type definitions
///////////////////////////////////////////////////////////////////////////

class Mesa;

class Game
{
  public:
        // Constructor/destructor
    Game(int rows, int cols, int nGarks);
    ~Game();

        // Mutators
    void play();

  private:
    Mesa* m_mesa;
};
#endif /* Game_hpp */
