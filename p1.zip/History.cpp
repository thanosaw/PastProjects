//
//  History.cpp
//  Project1cs32
//
//  Created by Andrew Wang on 1/4/22.
//

#include "History.h"
#include "globals.h"
#include <iostream>
using namespace std;
History::History(int nRows, int nCols){
    m_nRows=nRows;
    m_nCols=nCols;
    for (int i=0;i<m_nRows;i++){
        for (int j=0;j<m_nCols;j++){
            arr[i][j]=0;
        }
    }
}

bool History::record(int r, int c){
    if (r<1||c<1||r>MAXROWS||c>MAXCOLS){
        return false;
    }
    arr[r-1][c-1]++;
    return true;
}

void History::display() const{
    clearScreen();
    for (int i=0;i<m_nRows;i++){
        for (int j=0;j<m_nCols;j++){
            if (arr[i][j]==0)
                cout << '.';
            else if (arr[i][j]<26&&arr[i][j]>0){
                cout << char('A'  +arr[i][j]-1);
            }
                
            else
                cout << 'Z';
            
            
        }
        cout << endl;
    }
    cout << endl;
}
